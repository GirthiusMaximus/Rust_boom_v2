# <Product name> — Design Brief

> **Product:** <Product name>
> **Artifact:** <Carbon plugin (`.cs`, server-side only) | HarmonyMod | both>
> **Status:** **Draft v0.1 — <one-line status>.** Open items are in §13.2.
> **Last updated:** <YYYY-MM-DD>
>
> **Read with:** `CARBON_PLUGIN_PLAYBOOK.MD` (process and build order), `CarbonMod.MD` (API surface),
> `Exceptions.md` (failure standard), `Rust.MD` (engine and networking limits), `DontJustRollWithIt.MD`
> (evidence tags and the ask-before-inventing rule).

---

## 0. How to use this document

This is the product source of truth. It describes **what the product is and does**, not how each line is
written. When the implementation and this document disagree, one of them is wrong. Say which, then amend the
document in the same change as the code.

- Requirements carry IDs (`FR-xx`) and a MoSCoW priority (Must, Should, Could, Won't). Acceptance in §15 refers to them.
- Anything uncertain is marked `[ASSUMED]` or `[UNKNOWN]` and appears again in §13. Nothing may be silently
  invented. Per `DontJustRollWithIt.MD`, an unknown becomes a question, not a guess.
- Numbers in the configuration sketch (§7.1) are **starting points for tuning on a live server**, not proven values.
- Every change gets a line in §16.
- Delete any section that does not apply, and write one line saying why it was removed.

---

## 1. Vision

<Two or three sentences: what the player or admin experiences, and why it matters.>

<Scope statement: what this version delivers, and what it does not.>

---

## 2. Goals and non-goals

### 2.1 Goals

- G1 <measurable goal>
- G2 <measurable goal>

### 2.2 Non-goals (v1)

- <Explicitly out of scope, with the reason.>

---

## 3. Success criteria

Each criterion is measured on a live server, and the measurement is recorded in §16.

| # | Criterion | Measure | Target |
|---|---|---|---|
| 1 | <criterion> | <how it is measured> | <number, with unit> |

---

## 4. Cast of objects (glossary)

| Term | Meaning |
|---|---|
| <term> | <definition, and the game or framework object it maps to> |

---

## 5. The experience — storyboard

### 5.1 Beat sheet

<Ordered list of what happens, from trigger to end. One line per beat.>

### 5.2 Phase state machine

<States and transitions. Include the abort path from every state.>

### 5.3 Trajectory or timing model

<Any motion, timing or sequence model, with the formulae or steps and their units.>

---

## 6. Functional requirements

Each requirement has an ID, a priority and an acceptance note.

### 6.1 <Feature area>

| ID | Priority | Requirement | Acceptance |
|---|---|---|---|
| FR-01 | M | <what the system must do> | <how it is shown to work> |

### 6.2 Lifecycle, persistence and recovery

| ID | Priority | Requirement | Acceptance |
|---|---|---|---|
| FR-90 | M | Every run that starts ends in a known state, including on server restart and plugin reload. | Fault injection in §15. |

---

## 7. Configuration

### 7.1 Configuration sketch

```json
{
  "General": {
    "Debug": false,
    "DebugOverlay": false
  }
}
```

Values are starting points. Note the unit for every value.

### 7.2 Configuration UI

<Whether an in-game or web configuration UI is needed, who may use it, and what it may change.>

---

## 8. Debug tooling

Debug tooling is part of the product, not an afterthought. Each item below is either implemented or listed in §13 with a reason.

### 8.1 Debug mode (configuration `General.Debug`)

<What extra logging is written, and where.>

### 8.2 Debug overlay (configuration `General.DebugOverlay`)

<What is shown, to whom, and how it is turned off.>

### 8.3 Clear command

<The command that removes everything the product created, and its permission.>

---

## 9. Technical approach and feasibility

### 9.1 Verified building blocks

| Building block | Evidence | Source |
|---|---|---|
| <API or engine behaviour> | <how it was verified: live server, source, documentation> | <file, section or URL, with date> |

### 9.2 Proposed architecture

<Components, what each owns, and how they talk. A short diagram is useful.>

### 9.3 Risks

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| <risk> | L / M / H | L / M / H | <mitigation, and the check that proves it> |

### 9.4 Feasibility checks (before building on an assumption)

Each risky assumption is proven on a live server before the feature depends on it. A feasibility check:

1. states the single question it answers,
2. runs in a disposable plugin or a copy of the feature, never in the product code,
3. logs enough to answer the question without re-running,
4. cleans up everything it created,
5. records its result, with date and server build, in §16.

| Check | Question | Result | Date |
|---|---|---|---|
| FC-01 | <question> | <pending / yes / no> | <date> |

---

## 10. Asset and effect register

| Asset or effect | Source | Used by | Status |
|---|---|---|---|
| <prefab, sound or effect name> | <vanilla or custom, with path> | <FR IDs> | <resolved / ASSET-TBD> |

Every `ASSET-TBD` is listed in §13.2 and must be resolved before §15.

---

## 11. Balance, performance and server-health budgets

| Budget | Limit | Measured | Source of limit |
|---|---|---|---|
| Hook time per call | <ms> | <value> | <how measured> |
| Entities created per run | <count> | <value> | <reason> |
| Server tick time added | <ms> | <value> | <reason> |

---

## 12. Failure behaviour

For each failure, state what the player sees, what the admin sees, what is logged, and what is cleaned up.

| Failure | Player sees | Admin sees | Logged | Cleanup |
|---|---|---|---|---|
| <failure> | <text> | <text> | <log file and level> | <what is removed or reset> |

Fail-open or fail-closed is chosen per feature and written here (`Exceptions.md` §5).

---

## 13. Decision register

### 13.1 Resolved

| ID | Question | Decision | Date | By |
|---|---|---|---|---|
| Q-01 | <question> | <decision> | <date> | <name or role> |

### 13.2 Remaining

| ID | Question | Why it matters | Blocks |
|---|---|---|---|
| Q-xx | <question> | <reason> | <FR IDs or milestones> |

### 13.3 Work items created by the answers

| Item | Created by | Owner | Status |
|---|---|---|---|
| <work item> | <Q-ID> | <owner> | <status> |

---

## 14. Roadmap

| Milestone | Scope | Exit condition |
|---|---|---|
| M0 | Feasibility checks in §9.4 | Every FC answered, §13 updated |
| M1 | <scope> | <exit condition> |
| M2 | <scope> | <exit condition> |

---

## 15. Definition of done

- [ ] All **M** requirements in §6 are implemented and demonstrated on the live server.
- [ ] All success criteria in §3 are measured, with numbers recorded in §16.
- [ ] All §10 assets are resolved (no `ASSET-TBD` in the shipped configuration).
- [ ] All §13 questions are answered and closed.
- [ ] Fault injection: every phase is aborted mid-run; no orphan entities, no stuck players.
- [ ] Plugin reload during a run: clean recovery.
- [ ] Exception log reviewed after a full run: no unexpected records.
- [ ] README updated, and this document updated to v1.0 with the change log.

---

## 16. Change log

| Version | Date | Change | By |
|---|---|---|---|
| 0.1 | <YYYY-MM-DD> | Initial framework: vision, requirements, configuration sketch, open questions. | <name> |

---

## Appendix A — Reference values (for tuning)

| Value | Source | Use |
|---|---|---|
| <value> | <file, section or URL> | <how it is used> |

## Appendix B — Document map for this product

| Question | Document |
|---|---|
| What is being built, and why? | This document, §1–§3 |
| What must it do? | §6 |
| How is it configured? | §7 |
| How is it debugged? | §8 |
| How is it built? | `CARBON_PLUGIN_PLAYBOOK.MD` |
| How do the APIs behave? | `CarbonMod.MD`, `Rust.MD` |
| What happens on failure? | `Exceptions.md`, §12 |
| How is the work done when unsure? | `DontJustRollWithIt.MD` |
| Is the code ready to hand over? | `COMPILE_CHECK.MD` |
