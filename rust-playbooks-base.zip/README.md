# Rust Plugin Playbooks — Base Set

A reusable reference set for building C# Rust server plugins on **Carbon**, with a **HarmonyMod** fallback.
It is a template: copy it into a new project and tailor the project-specific documents before use.

## Contents

| Document | Use | Project-specific? |
|---|---|---|
| `DontJustRollWithIt.MD` | Working agreement: evidence tags, when to stop and ask, environment profile, hand-off and feedback packets, decision log. | Fill in the environment profile. |
| `CARBON_PLUGIN_PLAYBOOK.MD` | Process: artifact choice, project setup, standards, skeleton, hooks, Harmony fallback, error handling, testing, release, wipe and incident runbooks. | No. |
| `CarbonMod.MD` | Carbon and HarmonyMod API reference: install, lifecycle, hooks, commands, permissions, config and data, timers, CUI and LUI, Bridge, extensions, patching, performance, logging. | No. |
| `Rust.MD` | Client and server internals: authority model, tick loop, entities, network IDs, RPC and visibility, wire protocol, spawning and pooling, custom-asset limits. | No. |
| `Senior_C.MD` | Senior C#: runtime caveats, idioms, testing, patterns, async, concurrency, security, databases, architecture. | No. |
| `Exceptions.md` | Exception standard: boundary guards, a global guard, a separate per-plugin exception log, code for plugins, extensions and HarmonyMods, fault-injection tests. | No. |
| `RESEARCH_REVIEW.MD` | Source recency and accuracy audit, with corrections. Re-run it when the sources change. | Update the audit date and sources. |
| `COMPILE_CHECK.MD` | Pre-delivery compile checks, known traps, and the error log. | Set the script path and add project errors. |
| `DESIGN_BRIEF.md` | **Template** for the product design brief: vision, requirements, configuration, debug tooling, risks, decisions, roadmap, change log. | Yes. Fill in for each product. |

## Read order

1. `DontJustRollWithIt.MD`: how the work is done when something is uncertain.
2. `CARBON_PLUGIN_PLAYBOOK.MD`: the build process, in order.
3. The reference the task needs (`CarbonMod.MD`, `Rust.MD`, `Senior_C.MD`).
4. For a product: `DESIGN_BRIEF.md` says what is being built; the playbook says how.

**Rule:** evidence or assumption, never a silent guess. See `DontJustRollWithIt.MD`.

## How the set fits together

Five layers, each answering a different question: **method → process → reference → standard → audit**.
Every topic has one owning document. The others point at it instead of restating it, so an edit lands in one place.

| Layer | Owner | Question it answers | Defers to |
|---|---|---|---|
| Method | `DontJustRollWithIt.MD` | How do we work when something is uncertain? | — |
| Process | `CARBON_PLUGIN_PLAYBOOK.MD` | What do I do next, in order, to ship this? | All reference and standard documents |
| Reference | `CarbonMod.MD` | What is true about the framework (Carbon and Harmony)? | `Rust.MD` for engine behaviour |
| Reference | `Rust.MD` | What is true about the engine and the wire? | `CarbonMod.MD` for API shape |
| Reference | `Senior_C.MD` | What is good C# on this runtime? | `Exceptions.md` for failure policy |
| Standard | `Exceptions.md` | What must every plugin do about failure? | — (the definition of done) |
| Audit | `RESEARCH_REVIEW.MD` | Why believe the rest, and what is still uncertain? | Every document's sources section |

The playbook is the only procedural document. Follow it in order. Everything else is looked up by section.

## Routing

| Situation | Start at | Then |
|---|---|---|
| New plugin | Playbook §1 (artifact), §2 (setup), §4 (skeleton) | `CarbonMod.MD` §3–§6; `Exceptions.md` §6, §9–§10 |
| No Carbon hook exists | Playbook §6 | `CarbonMod.MD` §5, §13–§14 |
| Hook, command or timer misbehaves | Playbook §11, then `CarbonMod.MD` §19 | `Exceptions.md` §3, §6, §8 |
| Designing exception handling | `Exceptions.md` §5–§9 | `Senior_C.MD` §1.9; Playbook §11 |
| API signature in doubt | `CarbonMod.MD` | `Rust.MD` for engine behaviour; `RESEARCH_REVIEW.MD` §4 for risk |
| Performance work | Playbook §13 | `CarbonMod.MD` §15; `Rust.MD` §13 |
| Security review | `Senior_C.MD` §7 | `CarbonMod.MD` §16; `Exceptions.md` §8.5 |
| Release or incident | Playbook §14–§16 | `DontJustRollWithIt.MD` §8–§9 (packets) |
| Compile error reported | `COMPILE_CHECK.MD` §3, §5 | Add the new error to §5 |
| Conflicting or missing information | `DontJustRollWithIt.MD` §4–§5 | Ask before implementing |
| "Are these documents still right?" | `RESEARCH_REVIEW.MD` | §3 corrections, §4 residual risks |

## Tailoring the set for a new project

1. Copy the set into the project repository, in a `docs/` folder or the root, as the team prefers.
2. Fill in the environment profile in `DontJustRollWithIt.MD`: the server, the framework version, and what the
   operator can run and report.
3. Copy `DESIGN_BRIEF.md` for the product and fill in every `<placeholder>`. Remove the sections that do not apply,
   and record why.
4. Set the precheck script path in `COMPILE_CHECK.MD` and build the script (its §4 describes the rules).
5. Keep the project-specific material (feasibility checks, live test results, vendor research) in the project's
   own files, not in this base set.
6. Update `RESEARCH_REVIEW.MD` with the date and sources you verified.

## Maintenance

- Every change to a shared document goes into this base set first, then into the projects that use it.
- Each document has its own version history or sources section. Record the date and source of every new fact.
